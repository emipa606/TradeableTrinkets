﻿using RimWorld;
using Verse;

namespace CM_Tradeable_Trinkets
{
    public class Trinket : ThingWithComps
    {
    }
}
