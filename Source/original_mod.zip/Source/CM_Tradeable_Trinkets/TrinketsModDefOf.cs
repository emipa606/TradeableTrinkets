﻿using System.Collections.Generic;

using RimWorld;
using Verse;

namespace CM_Tradeable_Trinkets
{
    [DefOf]
    public static class TrinketsModDefOf
    {
        public static JobDef CM_Tradeable_Trinkets_Job_PlayWithTrinket;
    }
}
