# CM_Tradeable_Trinkets
 A Rimworld mod that adds craftable trinkets that can be used for recreation or sold for profit.
